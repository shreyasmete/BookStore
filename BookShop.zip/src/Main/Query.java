/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author shreyas
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Query {
        Statement sm;
	Connection con=null;
	void resolveDBMS(){ //create all the table and procedures if not exists
        try
		{
                    String qus[]={
                        "CREATE table billno(billno int(11))",
                        "INSERT into billno values(0)",
                        "CREATE table books(id INT(9) NOT NULL AUTO_INCREMENT, name VARCHAR(255) NULL DEFAULT NULL , author VARCHAR(255) NULL DEFAULT NULL , mrp INT(11) NULL DEFAULT NULL , noc INT(11) NULL DEFAULT NULL , location VARCHAR(900) NULL DEFAULT NULL , PRIMARY KEY (id))",
                        "CREATE table credit(username varchar(255), password varchar(255))",
                        "INSERT into credit values(\"admin\",\"admin\")",
                        "CREATE table customer(mob varchar(13),name varchar(255))",
                        "CREATE table storeinfo(name varchar(255),address varchar(2000),contact varchar(255))",
                        "Insert into storeinfo values(\"Store name\",\"Store address\",\"Contact info\")"
                    };
                        Class.forName("com.mysql.jdbc.Driver");
                        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","");
                        sm=con.createStatement();
                        try{
                            sm.executeUpdate("CREATE DATABASE BookStore");
                        }catch(Exception e){
                        
                        }
                        
                        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BookStore?autoReconnect=true&useSSL=false","root","");
                        sm=con.createStatement();
                        
                                for(String s:qus){
                                try{
                                    sm.executeUpdate(s);
                                     }catch(Exception e){}
                            }
                       
                        sm.execute(
                                "CREATE PROCEDURE `incbillno`()"
                                + "BEGIN "
                                + "UPDATE billno SET billno = billno+1; "
                                + "END"
                                );
               }
		catch(SQLException e)
		{
			System.out.println(e);	
		} catch (ClassNotFoundException ex) {
                Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
            }
    
        }
	public ResultSet execute(String query){
		
		try
		{
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BookStore?autoReconnect=true&useSSL=false","root","");	
		}
		catch(SQLException e)
		{
			System.out.println(e);	
		}
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{

			try
			{			
				System.out.println("Connection successful");
				
				sm=con.createStatement();
				
				ResultSet set=sm.executeQuery(query);
				
				
				
				return set;
			}
			catch(SQLException e)
			{
				System.out.println(e);
				System.out.println("error 420");
			}
			}
		
		return null;
	}
        
       public void insertBook(String table,String name,String author,int mrp,int noc ,String loc){
		
		try
		{
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BookStore?autoReconnect=true&useSSL=false","root","");	
		}
		catch(SQLException e)
		{
			System.out.println(e);	
		}
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{

			try
			{			
				System.out.println("Connection successful");
				
			 String query = " insert into "+table+" (id,name, author, mrp, noc, location)"
+ " values (?, ?, ?, ?, ?,?)";

      // create the mysql insert preparedstatement
      PreparedStatement preparedStmt = con.prepareStatement(query);
      preparedStmt.setInt (1, 0);
      preparedStmt.setString (2, name);
      preparedStmt.setString  (3, author);
      preparedStmt.setInt(4, mrp);
      preparedStmt.setInt(5, noc);
      preparedStmt.setString(6, loc);
      

      
      preparedStmt.execute();
				con.close();
				
				
			}
			catch(SQLException e)
			{
				System.out.println(e);
				System.out.println("error 420");
			}
			}
		
		
	}
       
       
       
       
       public void insertStoreInfo(String table,String name,String address,String contact){
		
		try
		{
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BookStore?autoReconnect=true&useSSL=false","root","");	
		}
		catch(SQLException e)
		{
			System.out.println(e);	
		}
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{

			try
			{			
                            System.out.println("Connection successful");
                            String query = " update "+table+" set name="+"'"+name+"'";
                            PreparedStatement preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            query = " update "+table+" set address="+"'"+address+"'";
                            preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            query = " update "+table+" set contact="+"'"+contact+"'";
                            preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
      
				
                            
                            
                            con.close();
				
				
			}
			catch(SQLException e)
			{
				System.out.println(e);
				System.out.println("error 420");
			}
			}
		
		
	}
       
       
       
       
       
       
       public void changeCredits(String table,String username,String password){
		
		try
		{
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BookStore?autoReconnect=true&useSSL=false","root","");	
		}
		catch(SQLException e)
		{
			System.out.println(e);	
		}
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{

			try
			{			
                            System.out.println("Connection successful");
                            String query = " update "+table+" set username="+"'"+username+"'";
                            PreparedStatement preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            query = " update "+table+" set password="+"'"+password+"'";
                            preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            
				
                            
                            
                            con.close();
				
				
			}
			catch(SQLException e)
			{
				System.out.println(e);
				System.out.println("error 420");
			}
			}
		
		
	}
       public void update(int id,int req){
		
		try
		{
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BookStore?autoReconnect=true&useSSL=false","root","");	
		}
		catch(SQLException e)
		{
			System.out.println(e);	
		}
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{

			try
			{			
                            System.out.println("Connection successful");
                            
                            String query = " update books set noc="+"noc-"+req+" WHERE id="+id;
                            System.out.println(query);
                            PreparedStatement preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                           
                            con.close();
				
				
			}
			catch(SQLException e)
			{
				System.out.println(e);
				System.out.println("error 420");
			}
			}
		
		
	}
       
               
             public void update(int id,String name,String author,int mrp,int noc,String loc){
		
		try
		{
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BookStore?autoReconnect=true&useSSL=false","root","");	
		}
		catch(SQLException e)
		{
			System.out.println(e);	
		}
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{

			try
			{			
                            System.out.println("Connection successful");
                            
                            String query = " update books set name='"+name+"' WHERE id="+id;
                            System.out.println(query);
                            PreparedStatement preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            
                            query = " update books set noc="+noc+" WHERE id="+id;
                            System.out.println(query);
                            preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            
                            query = " update books set author='"+author+"' WHERE id="+id;
                            System.out.println(query);
                            preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            
                            query = " update books set location='"+loc+"' WHERE id="+id;
                            System.out.println(query);
                            preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            
                            query = " update books set mrp="+mrp+" WHERE id="+id;
                            System.out.println(query);
                            preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                            
                           
                            
                            con.close();
				
				
			}
			catch(SQLException e)
			{
				System.out.println(e);
				System.out.println("error 420");
			}
			}
		
		
	}   
               
	public void closeconnection() {
		try {
			sm.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}

    void delete(int id) {
        
    try
		{
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/BookStore?autoReconnect=true&useSSL=false","root","");	
		}
		catch(SQLException e)
		{
			System.out.println(e);	
		}
		if(con==null)
		{
			System.out.println("Connection failed");
		}
		else
		{

			try
			{			
                            System.out.println("Connection successful");
                            
                            String query = " delete from books WHERE id="+id;
                            System.out.println(query);
                            PreparedStatement preparedStmt = con.prepareStatement(query);
                            preparedStmt.execute();
                           
                            
                           
                            
                            con.close();
				
				
			}
			catch(SQLException e)
			{
				System.out.println(e);
				System.out.println("error 420");
			}
			}
		
		
    }
	
	
	
	
	
		
	
}
