/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author shreyas
 */
public class BillObj {
    public String bookName;
    public int req=0;
    public int cost=0;
    public int subTotal,id;
    BillObj(int id,String bookName,int noc,int cost){
        this.id=id;
        this.bookName=bookName;
        this.cost=cost;
        this.req=noc;
        subTotal=cost*noc;
    }
    BillObj(){
        
    }
}
