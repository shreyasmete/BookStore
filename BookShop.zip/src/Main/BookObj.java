/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

/**
 *
 * @author shreyas
 */



public class BookObj {
public int id;
public String name;
public String author;
public int mrp;
public int noc;
public String loc;
BookObj(int id ,String name,String author,int mrp,int noc,String loc){
    this.id=id;
    this.author=author;
    this.name=name;
    this.mrp=mrp;
    this.noc=noc;
    this.loc=loc;
}
}
